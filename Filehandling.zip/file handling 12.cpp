#include <iostream>   
#include <fstream>    
#include <string>     
using namespace std;
void displayFileContent(const string & filename) {
 ifstream file(filename); 
  if (file.is_open())
   { 
 cout << "File content:" << endl; 
 string line;
  while (getline(file,line)) 
	{ 
      cout << line << endl; 
    }
    file.close(); 
  } else {
    std::cout << "Failed to open the file." <<endl; 
  }
}
void decryptFile(const string & inputFile, const string & outputFile) {
  std::ifstream input(inputFile); 
  std::ofstream output(outputFile);

  if (input.is_open() && output.is_open())
   { 
    char ch; 

    while (input.get(ch)) { 
      ch--; 
      output.put(ch);
    }
    input.close(); 
    output.close();
   cout << "File decrypted successfully.\n" << std::endl; 
  } else {
    cout << "Failed to open the files.\n" << std::endl; 
  }
}

int main() {
  string inputFile = "encrypted_test.txt"; 
  displayFileContent("encrypted_test.txt"); 
  cout << endl;
  string outputFile = "decrypted_test.txt"; 
  decryptFile(inputFile, outputFile); 
  displayFileContent("decrypted_test.txt");
  cout << endl; 
  return 0; }