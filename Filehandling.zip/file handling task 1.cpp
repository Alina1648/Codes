#include<iostream>
#include <fstream>
#include<string>
using namespace std;
int main()
{ 
ifstream inputFile( "test.txt");
if (inputFile.is_open())
{ string line;
int lineCount=0;
while(getline(inputFile,line))
   lineCount++;
{ cout<<line<<endl;
}
inputFile.close();
cout<<"number of lines in the file"<<lineCount<<endl;
}

else{ cout<<"failed to create the file"<<endl;
}
return 0;
}
