#include<iostream>
using namespace std;
class Base
{ public:
	 void display ()
	{ cout<<"display base"<<endl;
	}
	virtual void show ()
	{ cout<<"show base"<<endl;
	}
};
class derived: public Base
{  public:
	void display()
	{ cout<<"display derived"<<endl;
	}
	void show()
	{ cout<<"show derived"<<endl;
	}
};
int main ()
{ 
Base B;
 derived D;
 Base *bptr;
 cout<<"bptr points to base"<<endl;
 bptr=&B;
 bptr->display();
 bptr-> show();
 cout<<"bptr points to derived"<<endl;
 bptr=&D;
 bptr->display();
 bptr->show();
	return 0;
	
}