#include<iostream>
using namespace std;
class A
{ public:
	int a,b,c;
	void getdata( int x,int y,int z);
	void display (void);
	void operator -();
};
void A::getdata(int x,int y,int z)
{ a=x;
b=y;
 c=z;
};
void A:: display (void)
{ 
cout<<a<<endl;
cout<<b<<endl;
cout<<c<<endl;
}
void A::operator -()
{a=-a;
b=-b;
c=-c;
}
int main()
{
A a;
a.getdata(23,56,78);
cout<<" a"<<endl;
a.display();
-a;
cout<<"\n a";
a.display();
return 0;
}