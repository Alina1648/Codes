#include<iostream>
using namespace std;
class student 
{ protected:
	int roll_number;
	public:
		void get_number(int a)
{ roll_number=a;
}
void put_number(void)
{ cout<<" roll number="<<roll_number<<"\n" ;
}};
class test : public student 
{ protected:
	float sub1;
	float sub2;
	public:
		void get_marks(float x,float y);
			{ sub1=x;
		sub2=y;
		}
		void put_marks(void)
	
		{ cout" marks obtained":<<"\n";
		cout<<"marks in sub1="<<sub1<<"\n";
		cout<<"marks in sub2="<<sub2<<"\n";
		}};
		class sports
		{ protected:
			float score;
			public:
				void get_score( float s)
				{ score=s;
				}
				void put_score(void)
				{ cout<<"sports wt:"<< score<<"\n";
				}};
				class result: public test,public sports
				{float total;
				public:
					void display(void);
				};
				void result :: display (void)
				{ total=sub1+sub2+score;
				put_number();
				put_marks();
				put_score();
				cout<<"total score="<<total<<"\n";
				}
				int main()
				{ result student_1;
				student_1.get_number(1234)
				student_1.get_marks(24.7,55.9);
				student_1.get_score(9.0)
				student_1.display();
				return 0;
				
				}
		
		
		
