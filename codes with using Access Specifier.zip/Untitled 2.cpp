#include<iostream>
using namespace std;
class parent 
{ public:
	int a;
	protected:
		int b;
		private: 
		int c;
};
class child:public parent
{ public: 
void in()
{ cout<<"enter a";
cin>>a;
cout<<"enter b";
cin>>b;
}
void out()
{ cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
};
int main()
{ child obj;
obj.in();
obj.out();
}