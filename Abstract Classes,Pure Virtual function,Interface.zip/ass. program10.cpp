#include <iostream>
using namespace std;
class Shape {
public:
    virtual ~Shape() = default;
    virtual double area() const = 0; 
    virtual double perimeter() const = 0; 
};
class Circle : public Shape {
public:
    Circle(double radius) : radius(radius) {}

    double area() const override {
        return radius * radius; 
    }

    double perimeter() const override {
        return 2  * radius; 
    }

private:
    double radius;
};
class Rectangle : public Shape {
public:
    Rectangle(double length, double width) : length(length), width(width) {}

    double area() const override {
        return length * width; 
    }

    double perimeter() const override {
        return 2 * (length + width);
    }

private:
    double length;
    double width;
};
class Triangle : public Shape {
public:
    Triangle(double a, double b, double c) : a(a), b(b), c(c) {}

    double area() const override {
        double s = (a + b + c) / 2; 
        return(s * (s - a) * (s - b) * (s - c)); 
    }

    double perimeter() const override {
        return a + b + c; 
    }

private:
    double a; 
    double b; 
    double c; 
};
int main() {
    Shape* circle = new Circle(5.0);
    Shape* rectangle = new Rectangle(4.0, 6.0);
    Shape* triangle = new Triangle(3.0, 4.0, 5.0);
    cout << "Circle:" << std::endl;
   cout << "Area: " << circle->area() << endl;
  cout << "Perimeter: " << circle->perimeter() << endl;
   cout << "\nRectangle:" << endl;
   cout << "Area: " << rectangle->area() << endl;
    cout << "Perimeter: " << rectangle->perimeter() <<endl;
   cout << "\nTriangle:" <<endl;
   cout << "Area: " << triangle->area() << endl;
    cout << "Perimeter: " << triangle->perimeter() << std::endl;
    delete circle;
    delete rectangle;
    delete triangle;
    
    return 0;
}
