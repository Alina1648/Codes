#include <iostream>
using namespace std;

class Base {
public:
    virtual void show() = 0;
};

class Derv1 : public Base {
public:
    void show() override {
        cout << "Message from Derv1" << endl;
    }
};

class Derv2 : public Base {
public:
    void show() override {
        cout << "Message from Derv2" << endl;
    }
};

int main() {
    Derv1 obj1;
    Derv2 obj2;

    obj1.show();
    obj2.show();

    return 0;
}
