#include<iostream>
using namespace std;

class Vehicle {
public:
    virtual void getNumberOfWheels() = 0;  // Pure virtual function
};

class Car : public Vehicle {
public:
    void getNumberOfWheels() override {
        cout << "4 wheels" << endl;
    }
};

class Bike : public Vehicle {
public:
    void getNumberOfWheels() override {
        cout << "2 wheels" << endl;
    }
};

int main() {
    Car C;
    Bike B;
    
    // Correct the array and pointer assignments
    Vehicle* vehicles[2];
    vehicles[0] = &C;
    vehicles[1] = &B;
    
    // Loop to display the number of wheels
    for (int i = 0; i < 2; ++i) {
        cout << "Vehicle " << i + 1 << " has ";
        vehicles[i]->getNumberOfWheels();
    }
    
    return 0;
}
