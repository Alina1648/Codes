#include <iostream>
using namespace std;

class PaymentMethod {
public:
    virtual void processPayment(double amount) = 0;
    virtual void refund(double amount) = 0;
};

class CreditCard : public PaymentMethod {
public:
    void processPayment(double amount) override {
        cout << "Processing credit card payment of $" << amount << endl;
    }
    void refund(double amount) override {
        cout << "Refunding $" << amount <<" to credit card" << endl;
    }
};

class PayPal : public PaymentMethod {
public:
    void processPayment(double amount) override {
        cout << "Processing PayPal payment of $" << amount << endl;
    }
    void refund(double amount) override {
        cout << "Refunding $" << amount << " to PayPal" << endl;
    }
};

class BankTransfer : public PaymentMethod {
public:
    void processPayment(double amount) override {
        cout << "Processing bank transfer payment of $" << amount << endl;
    }
    void refund(double amount) override {
        cout << "Refunding $" << amount << " to bank account" << endl;
    }
};

int main() {
    CreditCard creditCard;
    PayPal payPal;
    BankTransfer bankTransfer;

    PaymentMethod* paymentMethod = &creditCard;
    paymentMethod->processPayment(100.0);
    paymentMethod->refund(50.0);

    paymentMethod = &payPal;
    paymentMethod->processPayment(200.0);
    paymentMethod->refund(75.0);

    paymentMethod = &bankTransfer;
    paymentMethod->processPayment(300.0);
    paymentMethod->refund(150.0);

    return 0;
}

    