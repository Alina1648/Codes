#include <iostream>
#include <string>
using namespace std;
class Account {
protected:
    string accountNumber;
    string accountHolder;
    double balance;

public:
    Account(string accNo, string holder, double bal) : accountNumber(accNo), accountHolder(holder), balance(bal) {}

    void deposit(double amount) {
        balance += amount;
        cout << "Deposited $" << amount << ". New balance: $" << balance << endl;
    }
    virtual void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrew $" << amount << ". New balance: $" << balance << endl;
        } else {
            cout << "Insufficient balance!" << endl;
        }
    }
    double balanceInquiry() const {
        return balance;
    }
    void displayDetails() const {
        cout << "Account Number: " << accountNumber << endl;
        cout << "Account Holder: " << accountHolder << endl;
        cout << "Balance: $" << balance << endl;
    }
};
class SavingsAccount : public Account {
private:
    double interestRate;

public:
    SavingsAccount(string accNo, string holder, double bal, double rate)
        : Account(accNo, holder, bal), interestRate(rate) {}
    void addInterest() {
        double interest = balance * (interestRate / 100);
        balance += interest;
        cout << "Interest added: $" << interest << ". New balance: $" << balance << endl;
    }
};
class CurrentAccount : public Account {
private:
    double overdraftLimit;

public:
    CurrentAccount(string accNo, string holder, double bal, double overdraft)
        : Account(accNo, holder, bal), overdraftLimit(overdraft) {}
    void withdraw(double amount) override {
        if (amount <= balance + overdraftLimit) {
            balance -= amount;
            cout << "Withdrew $" << amount << ". New balance: $" << balance << endl;
        } else {
            cout << "Overdraft limit exceeded!" << endl;
        }
    }
};
int main() {
    
    SavingsAccount savings("123456789", "John Doe", 1000.0, 2.5);
    CurrentAccount current("987654321", "Jane Doe", 500.0, 300.0);
    cout << "Savings Account:" << endl;
    savings.deposit(200);
    savings.withdraw(100);
    savings.addInterest();
    savings.displayDetails();
    cout << endl;
    cout << "Current Account:" << endl;
    current.deposit(500);
    current.withdraw(1000); 
    current.withdraw(800);  
    current.displayDetails();

    return 0;
}
