#include<iostream>
using namespace std;
class shape {
public:
    virtual void draw() = 0; 
};

class Circle : public shape
 {
public:
    void draw() override
	 {
        cout << "my drawing skill is very bad" << endl;
    }
};
class Rectangle : public shape
 {
public:
    void draw() override 
	{
        cout << "drawing is not easy" << endl;
    }
};

int main()
 {
    Circle C;
    Rectangle R;
    shape* shapes[2];
   shapes[0] = &C;
shapes[1] = &R;
    for (int i = 0; i < 2; ++i) {
        cout << "shape " << i + 1 <<endl;
       shapes[i]-> draw();
    }
    return 0;
}
