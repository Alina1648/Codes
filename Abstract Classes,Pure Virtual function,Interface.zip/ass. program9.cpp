#include <iostream>
using namespace std;
class Shape {
public:
    virtual ~Shape() = default;
    virtual void draw() const = 0; 
    virtual double getArea() const = 0;
};
class Circle : public Shape {
public:
    Circle(double radius) : radius(radius) {}

    void draw() const override {
      cout << "Drawing a circle with radius " << radius << std::endl;
    }
    double getArea() const override {
        return radius * radius; 
    }
private:
    double radius;
};
class Rectangle : public Shape {
public:
    Rectangle(double width, double height) : width(width), height(height) {}

    void draw() const override {
     cout << "Drawing a rectangle with width " << width << " and height " << height << std::endl;
    }

    double getArea() const override {
        return width * height; 
    }

private:
    double width;
    double height;
};
class Triangle : public Shape {
public:
    Triangle(double base, double height) : base(base), height(height) {}

    void draw() const override {
       cout << "Drawing a triangle with base " << base << " and height " << height << std::endl;
    }

    double getArea() const override {
        return 0.5 * base * height; 
    }

private:
    double base;
    double height;
};
int main() {
    Shape* circle = new Circle(5.0);
    Shape* rectangle = new Rectangle(4.0, 6.0);
    Shape* triangle = new Triangle(3.0, 7.0);
    circle->draw();
    std::cout << "Area of circle: " << circle->getArea() << endl;
    rectangle->draw();
    std::cout << "Area of rectangle: " << rectangle->getArea() << endl;
    
    triangle->draw();
    std::cout << "Area of triangle: " << triangle->getArea() <<endl;
    delete circle;
    delete rectangle;
    delete triangle;
    
    return 0;
}
