#include <iostream>
#include <string>
using namespace std;
class Fruit {
protected:
    string color;
public:
    // Constructor
    Fruit(string c) : color(c)
	 {
	}
    void showColor() 
	 {
        cout << "This is a fruit and its color is " << color << "." << endl;
    }
    virtual void taste()  = 0;
    virtual void eatingMethod() = 0;
};
class Apple : public Fruit {
public:
    
    Apple(string c) : Fruit(c) {}
    void taste() {
        cout << "The taste of an apple is sweet " << endl;
    }
    void eatingMethod()
	{
        cout << "You can eat an apple raw or slice it into pieces." << endl;
    }
};
class Banana : public Fruit {
public:
    Banana(string c) : Fruit(c) {}
    void taste() 
	 {
        cout << "The taste of a banana is sweet ." << endl;
    }
    void eatingMethod() 
	{
        cout << "You can peel a banana and eat it directly." << endl;
    }
};

int main() {
    Apple myApple("Red");
    Banana myBanana("Yellow");
    myApple.showColor();
    myApple.taste();
    myApple.eatingMethod();
    cout << endl;
    myBanana.showColor();
    myBanana.taste();
    myBanana.eatingMethod();
    return 0;
}

