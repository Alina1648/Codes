#include <iostream>
using namespace std;
class Shape {
public:
    virtual double calculateArea() = 0; 
};
class Square : public Shape {
private:
    double side;

public:
    Square(double s) : side(s)
	 {
	}
    double calculateArea() 
	 {
        return side * side;
    }
};
class Triangle : public Shape {
private:
    double base, height;

public:
    Triangle(double b, double h) : base(b), height(h)
	 {
	 }
    double calculateArea() {
        return 0.5 * base * height;
    }
};
int main()
{
    Square mySquare(5.0);
    Triangle myTriangle(3.0, 4.0);
    Shape* shapes[2];
    shapes[0] = &mySquare;
    shapes[1] = &myTriangle;
    for (int i = 0; i < 2; ++i) {
        cout << "Area: " << shapes[i]->calculateArea() << endl;
    }

    return 0;
}
